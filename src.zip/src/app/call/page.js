import LiveChatWeb from '@/components/LiveChatWeb'
import React from 'react'

export default function page() {
    return (
        <>
            <LiveChatWeb room="general" />
        </>
    )
}
