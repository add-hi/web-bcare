"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";

const initial = {
    list: [],
    pagination: { limit: 10, offset: 0, total: 0, pages: 0 },
    loading: false,
    error: null,

    // === tambahan untuk DETAIL ===
    byId: {},            // cache detail: { [ticketId]: detailObject }
    detailLoading: false,
    detailError: null,
};

const useTicketStore = create(
    persist(
        (set, get) => ({
            ...initial,

            // list state
            setLoading: (loading) => set({ loading }),
            setError: (error) => set({ error }),
            setTickets: (list) => set({ list }),
            setPagination: (p) =>
                set({
                    pagination: {
                        limit: Number(p?.limit ?? 10),
                        offset: Number(p?.offset ?? 0),
                        total: Number(p?.total ?? 0),
                        pages: Number(p?.pages ?? 0),
                    },
                }),

            // detail state
            setDetailLoading: (detailLoading) => set({ detailLoading }),
            setDetailError: (detailError) => set({ detailError }),
            upsertDetail: (id, data) =>
                set((s) => ({ byId: { ...s.byId, [id]: data } })),
            getDetail: (id) => get().byId?.[id],

            reset: () => set({ ...initial }),
        }),
        { name: "ticket" }
    )
);

export default useTicketStore;
