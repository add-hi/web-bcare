"use client";
import { useCallback, useMemo } from "react";
import httpClient from "@/lib/httpClient";
import useTicketStore from "@/store/ticketStore";

/** Ambil token dari localStorage key "auth"
 * {"state":{"accessToken":"Bearer <jwt>", ...}, "version": 1}
 */
function getAccessToken() {
    try {
        if (typeof window === "undefined") return "";
        const raw = localStorage.getItem("auth");
        if (!raw) return "";
        const parsed = JSON.parse(raw);
        const token = parsed?.state?.accessToken || "";
        return token.startsWith("Bearer ") ? token : `Bearer ${token}`;
    } catch {
        return "";
    }
}

export default function useTicket() {
    const {
        // list
        list,
        pagination,
        loading,
        error,
        setLoading,
        setError,
        setTickets,
        setPagination,

        // detail
        byId,
        detailLoading,
        detailError,
        setDetailLoading,
        setDetailError,
        upsertDetail,
        getDetail,
    } = useTicketStore();

    const BASE = useMemo(() => {
        const v =
            process.env.NEXT_PUBLIC_TICKET_API_BASE_URL ||
            "https://275232686ea9.ngrok-free.app";
        return v.replace(/\/$/, "");
    }, []);

    // === LIST ===
    const fetchTickets = useCallback(
        async ({ limit = 10, offset = 0 } = {}) => {
            setLoading(true);
            setError(null);
            try {
                const Authorization = getAccessToken();
                if (!Authorization) throw new Error("Token tidak ditemukan. Silakan login ulang.");

                const res = await httpClient.get("/v1/tickets", {
                    baseURL: BASE,
                    params: { limit, offset },
                    headers: {
                        Accept: "application/json",
                        Authorization,
                        "ngrok-skip-browser-warning": "true",
                    },
                });

                const payload = res?.data;
                if (!payload?.success) {
                    throw new Error(payload?.message || "Gagal mengambil tiket");
                }

                setTickets(payload.data || []);
                setPagination({
                    limit: payload?.pagination?.limit ?? limit,
                    offset: payload?.pagination?.offset ?? offset,
                    total: payload?.pagination?.total ?? (payload?.data?.length ?? 0),
                    pages: payload?.pagination?.pages ?? 1,
                });
            } catch (e) {
                setError(
                    e?.response?.data?.message ||
                    e?.message ||
                    "Terjadi kesalahan saat mengambil tiket"
                );
            } finally {
                setLoading(false);
            }
        },
        [BASE, setLoading, setError, setTickets, setPagination]
    );

    // === DETAIL ===
    const fetchTicketDetail = useCallback(
        async (id, { force = false } = {}) => {
            if (!id) throw new Error("ID tiket wajib diisi");

            if (!force) {
                const cached = getDetail(id);
                if (cached) return cached; // pakai cache
            }

            setDetailLoading(true);
            setDetailError(null);
            try {
                const Authorization = getAccessToken();
                if (!Authorization) throw new Error("Token tidak ditemukan. Silakan login ulang.");

                const res = await httpClient.get(`/v1/tickets/${id}`, {
                    baseURL: BASE,
                    headers: {
                        Accept: "application/json",
                        Authorization,
                        "ngrok-skip-browser-warning": "true",
                    },
                });

                const payload = res?.data;
                if (!payload?.success) {
                    throw new Error(payload?.message || `Gagal memuat detail tiket #${id}`);
                }

                const detail = payload.data;
                upsertDetail(id, detail);
                return detail;
            } catch (e) {
                const msg =
                    e?.response?.data?.message || e?.message || "Gagal memuat detail tiket";
                setDetailError(msg);
                throw new Error(msg);
            } finally {
                setDetailLoading(false);
            }
        },
        [BASE, getDetail, upsertDetail, setDetailLoading, setDetailError]
    );

    return {
        // list state
        list,
        pagination,
        loading,
        error,

        // detail state
        byId,
        detailLoading,
        detailError,

        // actions
        fetchTickets,
        fetchTicketDetail,
        getTicket: getDetail,
    };
}
